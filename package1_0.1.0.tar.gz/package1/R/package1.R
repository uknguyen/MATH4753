#' MATH 4753 Package
#'
#' Contains functions created for the University of Oklahoma MATH 4753 course
#'
#' @docType package
#'
#' @author U. Kristine Nguyen \email{uyennhu.k.nguyen-1@ou.edu}
#'
#' @name package1
NULL
